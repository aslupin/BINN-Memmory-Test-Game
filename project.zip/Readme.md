Embedded System (01204322) Year 2019

Introduction : Binn is a game for relaxing and brain training that comes with 6 led rgb lights at display, 3 led rgb lights with oled and 3 buttons on controller. This is a memory test game, in game you have to remember all the colors flashing on the display. Until the light goes out, you have to press the button according to the led color in the correct order.

Source code :
	- controller
	- display
	- player
Libralies :
	- espnow
	- time
	- network
	- ubinascii
	- Pin
	- random
	- _thread
Board schematic :
	- controller
	- display
	- player

Eqiupment :
player :
	- ESP32-WROOM-32
	- OLED 128x64
	- RGB LED
	- press Switch
	- Jumper wire female to female

controller :
	- ESP32-WROOM-32
	- LED
	- Resistor 330 ohm
	- press Switch
	- toggle Switch
	- Jumper wire female to female
display :
	- ESP32-WROOM-32
	- RGB LED
	- STM32
	- Jumper wire female to female

Developers :
6010500109 poon shotateerawasu
6010502543 chitsanupong voravijitchaikul
6010504651 kittapon junsupakul
6010504767 noraset potong
Department of Computer Engineering, Faculty of Engineering, Kasetsart University

Advisor :
Asst.Prof. Chaiporn   Jaikaeo
